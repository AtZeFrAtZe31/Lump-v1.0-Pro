package com.atze.lump
data class Message(val text: String, val fromUser: Boolean)
